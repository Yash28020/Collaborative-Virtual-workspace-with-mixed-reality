import React, { useState, useEffect, Suspense } from 'react';
import { gsap } from 'gsap';
import { NavigationBar } from './NavigationBar';
import { Scene3D } from './Scene3D';
import { VideoPlayer } from './VideoPlayer';
import { CollaborationPanel } from './CollaborationPanel';
import { PreviewMode } from './PreviewMode';
import { LoadingScreen } from './LoadingScreen';
import type { 
  CollaborationState, 
  VideoState, 
  SceneObject, 
  User, 
  AIMessage 
} from '../../types/collaboration';

export const Shared3DViewer: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [selectedObjectId, setSelectedObjectId] = useState<string | null>(null);

  // Mock data - in real app, this would come from props or context
  const [sceneObjects] = useState<SceneObject[]>([
    {
      id: '1',
      name: 'Interactive Cube',
      type: 'primitive',
      position: [0, 0, 0],
      rotation: [0, 0, 0],
      scale: [1, 1, 1],
      color: '#ff4444',
      isSelected: false
    },
    {
      id: '2',
      name: 'Collaborative Sphere',
      type: '3d-model',
      position: [3, 1, 2],
      rotation: [0, 0, 0],
      scale: [1.2, 1.2, 1.2],
      color: '#4444ff',
      isSelected: false
    },
    {
      id: '3',
      name: 'Design Element',
      type: 'primitive',
      position: [-2, 0.5, 1],
      rotation: [0, 0, 0],
      scale: [0.8, 0.8, 0.8],
      color: '#44ff44',
      isSelected: false
    }
  ]);

  const [collaborationState] = useState<CollaborationState>({
    users: [
      {
        id: '1',
        name: 'Alex Chen',
        avatar: '',
        color: '#ff6b6b',
        position: [1, 0, 1],
        isActive: true
      },
      {
        id: '2',
        name: 'Sarah Kim',
        avatar: '',
        color: '#4ecdc4',
        position: [-1, 0, -1],
        isActive: true
      },
      {
        id: '3',
        name: 'Mike Johnson',
        avatar: '',
        color: '#45b7d1',
        position: [2, 0, -2],
        isActive: false
      }
    ],
    messages: [
      {
        id: '1',
        type: 'suggestion',
        content: 'Consider adjusting the lighting angle to better highlight the cube\'s metallic properties.',
        timestamp: new Date(Date.now() - 300000),
        confidence: 87
      },
      {
        id: '2',
        type: 'insight',
        content: 'The collaborative sphere shows high interaction patterns. Users spend 40% more time examining this object.',
        timestamp: new Date(Date.now() - 180000),
        confidence: 94
      },
      {
        id: '3',
        type: 'analysis',
        content: 'Optimal viewing angle detected at 45° elevation for maximum visual impact of all objects.',
        timestamp: new Date(Date.now() - 60000),
        confidence: 91
      }
    ],
    focusPoint: [0, 0, 0],
    cameraMode: 'free'
  });

  const [videoState, setVideoState] = useState<VideoState>({
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 0.7,
    isPreviewMode: false
  });

  // Simulate loading process
  useEffect(() => {
    const loadingTimer = setInterval(() => {
      setLoadingProgress(prev => {
        if (prev >= 100) {
          clearInterval(loadingTimer);
          setTimeout(() => setIsLoading(false), 500);
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 200);

    return () => clearInterval(loadingTimer);
  }, []);

  const handleObjectClick = (objectId: string) => {
    setSelectedObjectId(selectedObjectId === objectId ? null : objectId);
    
    // Update objects selection state
    sceneObjects.forEach(obj => {
      obj.isSelected = obj.id === objectId && selectedObjectId !== objectId;
    });
  };

  const handleTogglePreview = () => {
    setIsPreviewMode(!isPreviewMode);
    setVideoState(prev => ({ 
      ...prev, 
      isPreviewMode: !isPreviewMode,
      isPlaying: !isPreviewMode 
    }));
  };

  const handleResetCamera = () => {
    // This would typically trigger a camera reset in the 3D scene
    console.log('Resetting camera view');
  };

  const handleToggleFullscreen = () => {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      document.documentElement.requestFullscreen();
    }
  };

  const handleSendMessage = (message: string) => {
    // In a real app, this would send the message to the collaboration system
    console.log('Sending message:', message);
  };

  if (isLoading) {
    return (
      <LoadingScreen 
        progress={loadingProgress}
        message="Initializing 3D workspace..."
      />
    );
  }

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden">
      <NavigationBar
        isPreviewMode={isPreviewMode}
        onTogglePreview={handleTogglePreview}
        onResetCamera={handleResetCamera}
        collaboratorCount={collaborationState.users.filter(u => u.isActive).length}
        onToggleChat={() => setIsChatOpen(!isChatOpen)}
        onToggleFullscreen={handleToggleFullscreen}
      />

      <div className="absolute inset-0 pt-16">
        <div className="relative w-full h-full">
          {/* 3D Scene */}
          <Suspense fallback={<div className="w-full h-full bg-gray-900 animate-pulse" />}>
            <Scene3D
              objects={sceneObjects}
              users={collaborationState.users}
              focusPoint={collaborationState.focusPoint}
              isPreviewMode={isPreviewMode}
              onObjectClick={handleObjectClick}
            />
          </Suspense>

          {/* Video Player (Bottom Right Corner) */}
          {!isPreviewMode && (
            <div className="absolute bottom-6 right-6 w-80 h-48">
              <VideoPlayer
                videoState={videoState}
                onVideoStateChange={(state) => setVideoState(prev => ({ ...prev, ...state }))}
                isVisible={true}
              />
            </div>
          )}

          {/* Preview Mode Overlay */}
          <PreviewMode
            isActive={isPreviewMode}
            videoState={videoState}
            onVideoStateChange={(state) => setVideoState(prev => ({ ...prev, ...state }))}
            onExitPreview={() => handleTogglePreview()}
          />

          {/* Collaboration Panel */}
          <CollaborationPanel
            users={collaborationState.users}
            messages={collaborationState.messages}
            isOpen={isChatOpen}
            onClose={() => setIsChatOpen(false)}
            onSendMessage={handleSendMessage}
          />
        </div>
      </div>
    </div>
  );
};