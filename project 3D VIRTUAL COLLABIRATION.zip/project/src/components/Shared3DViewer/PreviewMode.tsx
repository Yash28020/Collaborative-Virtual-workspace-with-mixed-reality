import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { VideoPlayer } from './VideoPlayer';
import type { VideoState } from '../../types/collaboration';

interface PreviewModeProps {
  isActive: boolean;
  videoState: VideoState;
  onVideoStateChange: (state: Partial<VideoState>) => void;
  onExitPreview: () => void;
}

export const PreviewMode: React.FC<PreviewModeProps> = ({
  isActive,
  videoState,
  onVideoStateChange,
  onExitPreview
}) => {
  const overlayRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (overlayRef.current) {
      gsap.to(overlayRef.current, {
        opacity: isActive ? 1 : 0,
        duration: 0.8,
        ease: "power2.out",
        pointerEvents: isActive ? 'auto' : 'none'
      });
    }
  }, [isActive]);

  if (!isActive) return null;

  return (
    <div
      ref={overlayRef}
      className="absolute inset-0 bg-black/95 backdrop-blur-sm z-20 flex items-center justify-center"
    >
      <div className="w-full max-w-4xl mx-auto p-6">
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-white mb-2">AI-Generated Preview</h2>
          <p className="text-gray-300">
            Watch an AI-generated summary of this 3D object and its collaborative features
          </p>
        </div>
        
        <VideoPlayer
          videoState={videoState}
          onVideoStateChange={onVideoStateChange}
          isVisible={true}
          className="w-full h-96 mb-6"
        />
        
        <div className="flex justify-center space-x-4">
          <button
            onClick={onExitPreview}
            className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200 font-medium"
          >
            Enter Interactive Mode
          </button>
          <button
            onClick={() => onVideoStateChange({ isPlaying: !videoState.isPlaying })}
            className="px-6 py-3 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors duration-200 font-medium"
          >
            {videoState.isPlaying ? 'Pause' : 'Play'} Preview
          </button>
        </div>
        
        {/* AI Summary Panel */}
        <div className="mt-8 bg-gray-900/50 rounded-lg p-6 border border-gray-800">
          <h3 className="text-lg font-bold text-white mb-4">AI Analysis Summary</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <div className="text-gray-400 mb-1">Object Type</div>
              <div className="text-white">3D Interactive Model</div>
            </div>
            <div>
              <div className="text-gray-400 mb-1">Complexity</div>
              <div className="text-green-400">Moderate</div>
            </div>
            <div>
              <div className="text-gray-400 mb-1">Collaboration Score</div>
              <div className="text-blue-400">High (8.5/10)</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};