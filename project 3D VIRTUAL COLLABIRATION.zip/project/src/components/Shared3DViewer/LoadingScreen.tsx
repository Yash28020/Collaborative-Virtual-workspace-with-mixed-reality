import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

interface LoadingScreenProps {
  progress: number;
  message?: string;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ 
  progress, 
  message = "Loading 3D Experience..." 
}) => {
  const progressRef = useRef<HTMLDivElement>(null);
  const dotsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (progressRef.current) {
      gsap.to(progressRef.current, {
        width: `${progress}%`,
        duration: 0.5,
        ease: "power2.out"
      });
    }
  }, [progress]);

  useEffect(() => {
    if (dotsRef.current) {
      const dots = dotsRef.current.children;
      gsap.set(dots, { opacity: 0.3 });
      
      const tl = gsap.timeline({ repeat: -1 });
      Array.from(dots).forEach((dot, index) => {
        tl.to(dot, { opacity: 1, duration: 0.3 }, index * 0.2)
          .to(dot, { opacity: 0.3, duration: 0.3 }, index * 0.2 + 0.3);
      });
    }
  }, []);

  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
      <div className="text-center">
        <div className="mb-8">
          <div className="w-16 h-16 mx-auto mb-4 border-2 border-red-600 rounded-full">
            <div className="w-full h-full bg-gradient-to-r from-red-600 to-red-500 rounded-full animate-pulse"></div>
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Netflix 3D</h2>
        </div>
        
        <div className="w-80 bg-gray-800 rounded-full h-2 mb-4 overflow-hidden">
          <div 
            ref={progressRef}
            className="h-full bg-gradient-to-r from-red-600 to-red-500 rounded-full"
            style={{ width: '0%' }}
          ></div>
        </div>
        
        <p className="text-gray-300 mb-2">{message}</p>
        <div ref={dotsRef} className="flex justify-center space-x-1">
          <div className="w-2 h-2 bg-red-600 rounded-full"></div>
          <div className="w-2 h-2 bg-red-600 rounded-full"></div>
          <div className="w-2 h-2 bg-red-600 rounded-full"></div>
        </div>
      </div>
    </div>
  );
};