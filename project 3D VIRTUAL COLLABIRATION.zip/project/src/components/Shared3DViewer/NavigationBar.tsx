import React, { useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Users, MessageSquare, Settings, Maximize } from 'lucide-react';
import { gsap } from 'gsap';

interface NavigationBarProps {
  isPreviewMode: boolean;
  onTogglePreview: () => void;
  onResetCamera: () => void;
  collaboratorCount: number;
  onToggleChat: () => void;
  onToggleFullscreen: () => void;
}

export const NavigationBar: React.FC<NavigationBarProps> = ({
  isPreviewMode,
  onTogglePreview,
  onResetCamera,
  collaboratorCount,
  onToggleChat,
  onToggleFullscreen
}) => {
  const navRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (navRef.current) {
      gsap.fromTo(navRef.current, 
        { y: -100, opacity: 0 },
        { y: 0, opacity: 1, duration: 1, ease: "power3.out", delay: 0.5 }
      );
    }
  }, []);

  const navItems = [
    {
      icon: isPreviewMode ? Play : Pause,
      label: isPreviewMode ? 'Interactive' : 'Preview',
      onClick: onTogglePreview,
      primary: true
    },
    {
      icon: RotateCcw,
      label: 'Reset View',
      onClick: onResetCamera
    },
    {
      icon: Users,
      label: `${collaboratorCount} Users`,
      badge: collaboratorCount > 0 ? collaboratorCount.toString() : undefined
    },
    {
      icon: MessageSquare,
      label: 'Chat',
      onClick: onToggleChat
    },
    {
      icon: Maximize,
      label: 'Fullscreen',
      onClick: onToggleFullscreen
    },
    {
      icon: Settings,
      label: 'Settings'
    }
  ];

  return (
    <nav 
      ref={navRef}
      className="fixed top-0 left-0 right-0 z-40 bg-black/80 backdrop-blur-md border-b border-gray-800"
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-red-600 rounded flex items-center justify-center">
                <span className="text-white font-bold text-sm">3D</span>
              </div>
              <h1 className="text-xl font-bold text-white">Collaborative Workspace</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {navItems.map((item, index) => (
              <button
                key={index}
                onClick={item.onClick}
                className={`relative flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-300 hover:bg-white/10 group ${
                  item.primary ? 'bg-red-600 hover:bg-red-700 text-white' : 'text-gray-300 hover:text-white'
                }`}
                aria-label={item.label}
              >
                <item.icon size={18} />
                <span className="hidden sm:inline text-sm font-medium">{item.label}</span>
                {item.badge && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
                <div className="absolute inset-0 bg-white/5 rounded-lg scale-0 group-hover:scale-100 transition-transform duration-300"></div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
};