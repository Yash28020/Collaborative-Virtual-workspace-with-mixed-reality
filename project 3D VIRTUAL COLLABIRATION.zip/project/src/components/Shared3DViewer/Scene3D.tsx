import React, { useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Box, Sphere, Text, Environment } from '@react-three/drei';
import { gsap } from 'gsap';
import * as THREE from 'three';
import type { SceneObject, User } from '../../types/collaboration';

interface Scene3DProps {
  objects: SceneObject[];
  users: User[];
  focusPoint: [number, number, number];
  isPreviewMode: boolean;
  onObjectClick: (objectId: string) => void;
}

const AnimatedObject: React.FC<{ 
  object: SceneObject; 
  isSelected: boolean;
  onClick: () => void;
}> = ({ object, isSelected, onClick }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const { camera } = useThree();

  useFrame((state) => {
    if (meshRef.current) {
      // Gentle floating animation
      meshRef.current.position.y = object.position[1] + Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
      
      // Rotate based on object type
      if (object.type === '3d-model') {
        meshRef.current.rotation.y = state.clock.elapsedTime * 0.2;
      }
      
      // Selection highlight
      if (isSelected) {
        meshRef.current.scale.setScalar(1 + Math.sin(state.clock.elapsedTime * 3) * 0.05);
      }
    }
  });

  const handleClick = (e: THREE.Event) => {
    e.stopPropagation();
    onClick();
    
    // Smooth camera transition to object
    gsap.to(camera.position, {
      duration: 1.5,
      x: object.position[0] + 3,
      y: object.position[1] + 2,
      z: object.position[2] + 3,
      ease: "power2.out"
    });
  };

  return (
    <group position={object.position}>
      {object.type === 'primitive' ? (
        <Box
          ref={meshRef}
          args={[1, 1, 1]}
          onClick={handleClick}
          scale={object.scale}
        >
          <meshPhysicalMaterial 
            color={object.color}
            metalness={0.7}
            roughness={0.2}
            emissive={isSelected ? object.color : '#000000'}
            emissiveIntensity={isSelected ? 0.2 : 0}
          />
        </Box>
      ) : (
        <Sphere
          ref={meshRef}
          args={[0.8, 32, 32]}
          onClick={handleClick}
          scale={object.scale}
        >
          <meshPhysicalMaterial 
            color={object.color}
            metalness={0.9}
            roughness={0.1}
            transmission={0.3}
            thickness={0.5}
            emissive={isSelected ? object.color : '#000000'}
            emissiveIntensity={isSelected ? 0.3 : 0}
          />
        </Sphere>
      )}
      
      {isSelected && (
        <Text
          position={[0, 2, 0]}
          fontSize={0.3}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
        >
          {object.name}
        </Text>
      )}
    </group>
  );
};

const UserAvatars: React.FC<{ users: User[] }> = ({ users }) => {
  return (
    <>
      {users.map((user) => (
        <group key={user.id} position={user.position}>
          <Sphere args={[0.2, 16, 16]}>
            <meshBasicMaterial color={user.color} />
          </Sphere>
          <Text
            position={[0, 0.5, 0]}
            fontSize={0.2}
            color="#ffffff"
            anchorX="center"
            anchorY="middle"
          >
            {user.name}
          </Text>
        </group>
      ))}
    </>
  );
};

const Scene3DContent: React.FC<Scene3DProps> = ({ 
  objects, 
  users, 
  focusPoint, 
  isPreviewMode,
  onObjectClick 
}) => {
  const controlsRef = useRef<any>(null);

  useEffect(() => {
    if (controlsRef.current && focusPoint) {
      gsap.to(controlsRef.current.target, {
        duration: 2,
        x: focusPoint[0],
        y: focusPoint[1],
        z: focusPoint[2],
        ease: "power2.out"
      });
    }
  }, [focusPoint]);

  return (
    <>
      <ambientLight intensity={0.4} />
      <pointLight position={[10, 10, 10]} intensity={1.5} color="#ffffff" />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#ff4444" />
      
      <Environment preset="night" />
      
      {objects.map((object) => (
        <AnimatedObject
          key={object.id}
          object={object}
          isSelected={object.isSelected}
          onClick={() => onObjectClick(object.id)}
        />
      ))}
      
      <UserAvatars users={users} />
      
      <OrbitControls
        ref={controlsRef}
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        maxDistance={20}
        minDistance={2}
        enabled={!isPreviewMode}
      />
    </>
  );
};

export const Scene3D: React.FC<Scene3DProps> = (props) => {
  return (
    <div className="w-full h-full">
      <Canvas
        camera={{ position: [5, 5, 5], fov: 60 }}
        gl={{ antialias: true, alpha: true }}
      >
        <Scene3DContent {...props} />
      </Canvas>
    </div>
  );
};