import React, { useRef, useEffect, useState } from 'react';
import { Bot, MessageSquare, Users, Lightbulb, TrendingUp, X } from 'lucide-react';
import { gsap } from 'gsap';
import type { User, AIMessage } from '../../types/collaboration';

interface CollaborationPanelProps {
  users: User[];
  messages: AIMessage[];
  isOpen: boolean;
  onClose: () => void;
  onSendMessage: (message: string) => void;
}

export const CollaborationPanel: React.FC<CollaborationPanelProps> = ({
  users,
  messages,
  isOpen,
  onClose,
  onSendMessage
}) => {
  const panelRef = useRef<HTMLDivElement>(null);
  const [activeTab, setActiveTab] = useState<'chat' | 'ai' | 'users'>('ai');
  const [newMessage, setNewMessage] = useState('');

  useEffect(() => {
    if (panelRef.current) {
      gsap.to(panelRef.current, {
        x: isOpen ? 0 : '100%',
        duration: 0.5,
        ease: "power3.out"
      });
    }
  }, [isOpen]);

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      onSendMessage(newMessage);
      setNewMessage('');
    }
  };

  const getMessageIcon = (type: AIMessage['type']) => {
    switch (type) {
      case 'suggestion': return <Lightbulb size={16} className="text-yellow-400" />;
      case 'insight': return <TrendingUp size={16} className="text-blue-400" />;
      case 'analysis': return <Bot size={16} className="text-green-400" />;
      default: return <Bot size={16} className="text-gray-400" />;
    }
  };

  const tabs = [
    { id: 'ai', label: 'AI Assistant', icon: Bot },
    { id: 'chat', label: 'Chat', icon: MessageSquare },
    { id: 'users', label: 'Users', icon: Users }
  ];

  return (
    <div
      ref={panelRef}
      className="fixed right-0 top-16 bottom-0 w-96 bg-black/90 backdrop-blur-md border-l border-gray-800 z-30 transform translate-x-full"
    >
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-800">
          <h2 className="text-lg font-bold text-white">Collaboration</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors duration-200"
            aria-label="Close panel"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-800">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 flex items-center justify-center space-x-2 px-4 py-3 text-sm font-medium transition-colors duration-200 ${
                activeTab === tab.id
                  ? 'text-red-400 border-b-2 border-red-400'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <tab.icon size={16} />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          {activeTab === 'ai' && (
            <div className="h-full flex flex-col">
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className="bg-gray-900/50 rounded-lg p-4 border border-gray-800"
                  >
                    <div className="flex items-center space-x-2 mb-2">
                      {getMessageIcon(message.type)}
                      <span className="text-sm font-medium text-white capitalize">
                        {message.type}
                      </span>
                      <span className="text-xs text-gray-400">
                        {message.confidence}% confidence
                      </span>
                    </div>
                    <p className="text-gray-300 text-sm leading-relaxed">
                      {message.content}
                    </p>
                    <div className="mt-2 text-xs text-gray-500">
                      {message.timestamp.toLocaleTimeString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'users' && (
            <div className="p-4 space-y-4">
              <div className="text-sm text-gray-400 mb-4">
                {users.length} active collaborators
              </div>
              {users.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center space-x-3 p-3 bg-gray-900/50 rounded-lg border border-gray-800"
                >
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: user.color }}
                  >
                    <span className="text-white text-sm font-bold">
                      {user.name.charAt(0)}
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="text-white font-medium">{user.name}</div>
                    <div className="text-xs text-gray-400">
                      {user.isActive ? 'Active now' : 'Away'}
                    </div>
                  </div>
                  <div className={`w-2 h-2 rounded-full ${
                    user.isActive ? 'bg-green-400' : 'bg-gray-600'
                  }`} />
                </div>
              ))}
            </div>
          )}

          {activeTab === 'chat' && (
            <div className="h-full flex flex-col">
              <div className="flex-1 overflow-y-auto p-4">
                <div className="text-center text-gray-400 text-sm">
                  Chat feature coming soon...
                </div>
              </div>
              <div className="p-4 border-t border-gray-800">
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Type a message..."
                    className="flex-1 bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:border-red-400"
                  />
                  <button
                    onClick={handleSendMessage}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200"
                  >
                    Send
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};