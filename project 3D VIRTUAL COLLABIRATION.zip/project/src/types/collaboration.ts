export interface User {
  id: string;
  name: string;
  avatar: string;
  color: string;
  position: [number, number, number];
  isActive: boolean;
}

export interface AIMessage {
  id: string;
  type: 'suggestion' | 'insight' | 'analysis';
  content: string;
  timestamp: Date;
  confidence: number;
}

export interface CollaborationState {
  users: User[];
  messages: AIMessage[];
  focusPoint: [number, number, number];
  cameraMode: 'free' | 'guided' | 'cinematic';
}

export interface VideoState {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isPreviewMode: boolean;
}

export interface SceneObject {
  id: string;
  name: string;
  type: '3d-model' | 'primitive';
  position: [number, number, number];
  rotation: [number, number, number];
  scale: [number, number, number];
  color: string;
  isSelected: boolean;
}