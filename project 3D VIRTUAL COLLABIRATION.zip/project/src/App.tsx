import React from 'react';
import { Shared3DViewer } from './components/Shared3DViewer';

function App() {
  return (
    <div className="w-full h-screen">
      <Shared3DViewer />
    </div>
  );
}

export default App;