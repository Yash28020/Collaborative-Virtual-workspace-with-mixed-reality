import React, { useRef, useEffect, useState } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize } from 'lucide-react';
import { gsap } from 'gsap';
import type { VideoState } from '../../types/collaboration';

interface VideoPlayerProps {
  videoState: VideoState;
  onVideoStateChange: (state: Partial<VideoState>) => void;
  isVisible: boolean;
  className?: string;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  videoState,
  onVideoStateChange,
  isVisible,
  className = ''
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [showControls, setShowControls] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    if (containerRef.current) {
      gsap.to(containerRef.current, {
        opacity: isVisible ? 1 : 0,
        scale: isVisible ? 1 : 0.9,
        duration: 0.5,
        ease: "power2.out"
      });
    }
  }, [isVisible]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (videoState.isPlaying) {
      video.play();
    } else {
      video.pause();
    }
  }, [videoState.isPlaying]);

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (video) {
      onVideoStateChange({
        currentTime: video.currentTime,
        duration: video.duration
      });
    }
  };

  const handleVolumeChange = (volume: number) => {
    const video = videoRef.current;
    if (video) {
      video.volume = volume;
      onVideoStateChange({ volume });
    }
  };

  const togglePlay = () => {
    onVideoStateChange({ isPlaying: !videoState.isPlaying });
  };

  const toggleMute = () => {
    const newVolume = videoState.volume > 0 ? 0 : 1;
    handleVolumeChange(newVolume);
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div
      ref={containerRef}
      className={`relative bg-black rounded-lg overflow-hidden ${className}`}
      onMouseEnter={() => {
        setIsHovered(true);
        setShowControls(true);
      }}
      onMouseLeave={() => {
        setIsHovered(false);
        setTimeout(() => setShowControls(false), 2000);
      }}
    >
      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleTimeUpdate}
        muted={videoState.volume === 0}
        poster="https://images.pexels.com/photos/2047905/pexels-photo-2047905.jpeg?auto=compress&cs=tinysrgb&w=800"
      >
        <source 
          src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" 
          type="video/mp4" 
        />
        Your browser does not support the video tag.
      </video>

      {/* Video Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none" />

      {/* Netflix-style Preview Badge */}
      {videoState.isPreviewMode && (
        <div className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded text-sm font-bold">
          AI PREVIEW
        </div>
      )}

      {/* Controls */}
      <div 
        className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 transition-opacity duration-300 ${
          showControls || isHovered ? 'opacity-100' : 'opacity-0'
        }`}
      >
        {/* Progress Bar */}
        <div className="w-full bg-gray-600 h-1 rounded-full mb-4 cursor-pointer">
          <div 
            className="bg-red-600 h-full rounded-full transition-all duration-300"
            style={{ 
              width: `${(videoState.currentTime / videoState.duration) * 100 || 0}%` 
            }}
          />
        </div>

        {/* Control Buttons */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={togglePlay}
              className="text-white hover:text-red-400 transition-colors duration-200"
              aria-label={videoState.isPlaying ? 'Pause' : 'Play'}
            >
              {videoState.isPlaying ? <Pause size={24} /> : <Play size={24} />}
            </button>

            <button
              onClick={toggleMute}
              className="text-white hover:text-red-400 transition-colors duration-200"
              aria-label={videoState.volume > 0 ? 'Mute' : 'Unmute'}
            >
              {videoState.volume > 0 ? <Volume2 size={20} /> : <VolumeX size={20} />}
            </button>

            <div className="flex items-center space-x-2">
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={videoState.volume}
                onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                className="w-20 accent-red-600"
              />
            </div>
          </div>

          <div className="flex items-center space-x-4 text-white text-sm">
            <span>
              {formatTime(videoState.currentTime)} / {formatTime(videoState.duration)}
            </span>
            <button
              className="text-white hover:text-red-400 transition-colors duration-200"
              aria-label="Fullscreen"
            >
              <Maximize size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};